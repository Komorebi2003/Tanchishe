﻿#include <stdio.h>
#include <time.h>
#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

#define U 1
#define D 2
#define L 3
#define R 4       //蛇的状态，U：上 ；D：下；L:左 R：右
#define MAX_USERNAME_LEN 20
#define MAX_PASSWORD_LEN 20
#define MAX_TOP_SCORES 10

typedef struct SNAKE //蛇身的一个节点
{
    int x;
    int y;
    struct SNAKE* next;
} snake;

// 用户数据结构
typedef struct {
    char username[MAX_USERNAME_LEN];
    char password[MAX_PASSWORD_LEN];
} User;

// 游戏日志数据结构
typedef struct {
    char username[MAX_USERNAME_LEN];
    time_t start_time;
    int duration;
    int score;
} GameLog;

// 历史最高分数据结构
typedef struct {
    char username[MAX_USERNAME_LEN];
    int score;
} TopScore;

//全局变量//
int score = 0, add = 10;  //总得分与每次吃食物得分。
int status, sleeptime = 200;  //每次运行的时间间隔
snake* head, * food;  //蛇头指针，食物指针
snake* q;  //遍历蛇的时候用到的指针
int endgamestatus = 0;  //游戏结束的情况，1：撞到墙；2：咬到自己；3：主动退出游戏。
char currentUser[MAX_USERNAME_LEN] = {0};  // 当前登录用户
time_t gameStartTime;  // 游戏开始时间
TopScore topScores[MAX_TOP_SCORES];
int snakeColor = 7;  // 默认白色
int inColorMenu = 0;  // 新增标志位，标识是否处于颜色选择菜单
int gamePaused = 0;  // 新增标志位，标识游戏是否暂停
int gameStarted = 0; // 新增标志位，标识游戏是否开始

//声明全部函数//
void Pos(int x, int y);
void setColor(int color);
void creatMap();
void initsnake();
int biteself();
void createfood();
void cantcrosswall();
void snakemove();
void pause();
void gamecircle();
void welcometogame();
void endgame();
void gamestart();
void registerUser();
int loginUser();
void showGameLogs();
void logGameStart();
void logGameEnd();
void showDifficultyMenu();
void loadTopScores();
void saveTopScores();
void showTopScores();
void playSound(int type);
void showColorMenu();
void updateTopScores();

void Pos(int x, int y)  //设置光标位置
{
    COORD pos;
    HANDLE hOutput;
    pos.X = x;
    pos.Y = y;
    hOutput = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleCursorPosition(hOutput, pos);
}

void setColor(int color)
{
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, color);
}

void creatMap()  //创建地图
{
    if (!inColorMenu && !gamePaused) {
        setColor(1);  // 蓝色
        int i;
        for (i = 0; i < 58; i += 2)  //打印上下边框
        {
            Pos(i, 0);
            printf("■");
            Pos(i, 26);
            printf("■");
        }
        for (i = 1; i < 26; i++)  //打印左右边框
        {
            Pos(0, i);
            printf("■");
            Pos(56, i);
            printf("■");
        }
        setColor(7);  // 恢复默认颜色
    }
}

void initsnake()  //初始化蛇身
{
    if (!inColorMenu && !gamePaused) {
        setColor(snakeColor);
        snake* tail;
        int i;
        tail = (snake*)malloc(sizeof(snake));  //从蛇尾开始，头插法，以x,y设定开始的位置//
        tail->x = 24;
        tail->y = 5;
        tail->next = NULL;
        for (i = 1; i <= 4; i++)
        {
            head = (snake*)malloc(sizeof(snake));
            head->next = tail;
            head->x = 24 + 2 * i;
            head->y = 5;
            tail = head;
        }
        while (tail != NULL)  //从头到为，输出蛇身
        {
            Pos(tail->x, tail->y);
            printf("■");
            tail = tail->next;
        }
        setColor(7);  // 恢复默认颜色
    }
}

int biteself()  //判断是否咬到了自己
{
    if (!inColorMenu && !gamePaused) {
        snake* self;
        self = head->next;
        while (self != NULL)
        {
            if (self->x == head->x && self->y == head->y)
            {
                return 1;
            }
            self = self->next;
        }
    }
    return 0;
}

void createfood()  //随机出现食物
{
    if (!inColorMenu && !gamePaused) {
        snake* food_1;
        srand((unsigned)time(NULL));
        food_1 = (snake*)malloc(sizeof(snake));

        // 保证食物坐标为偶数，能与蛇头对齐
        do {
            food_1->x = (rand() % 26 + 1) * 2;  // 1-26范围内的偶数
            food_1->y = rand() % 24 + 1;  // 1-24范围内的数
        } while (food_1->x == 0 || food_1->x == 56 || food_1->y == 0 || food_1->y == 26);

        // 检查食物是否与蛇身重叠
        q = head;
        int overlap = 0;
        while (q != NULL) {
            if (q->x == food_1->x && q->y == food_1->y) {
                overlap = 1;
                break;
            }
            q = q->next;
        }

        if (overlap) {
            free(food_1);
            createfood();  // 如果重叠，重新生成食物
            return;
        }

        food = food_1;
        setColor(4);  // 红色
        Pos(food->x, food->y);
        printf("■");
        setColor(7);  // 恢复默认颜色
    }
}

void cantcrosswall()  //不能穿墙
{
    if (!inColorMenu && !gamePaused) {
        if (head->x == 0 || head->x == 56 || head->y == 0 || head->y == 26)
        {
            endgamestatus = 1;
            endgame();
        }
    }
}

void snakemove()  //蛇前进,上U,下D,左L,右R
{
    if (!inColorMenu && !gamePaused && gameStarted) {
        snake* nexthead;
        cantcrosswall();

        nexthead = (snake*)malloc(sizeof(snake));
        if (status == U)
        {
            nexthead->x = head->x;
            nexthead->y = head->y - 1;
            if (nexthead->x == food->x && nexthead->y == food->y)  //如果下一个有食物//
            {
                playSound(1);  // 吃食物音效
                nexthead->next = head;
                head = nexthead;
                setColor(snakeColor);
                q = head;
                while (q != NULL)
                {
                    Pos(q->x, q->y);
                    printf("■");
                    q = q->next;
                }
                setColor(7);  // 恢复默认颜色
                score = score + add;
                free(food);  // 释放旧食物
                createfood();  // 生成新食物
            }
            else  //如果没有食物//
            {
                nexthead->next = head;
                head = nexthead;
                setColor(snakeColor);
                q = head;
                while (q->next->next != NULL)
                {
                    Pos(q->x, q->y);
                    printf("■");
                    q = q->next;
                }
                Pos(q->next->x, q->next->y);
                printf("  ");
                free(q->next);
                q->next = NULL;
                setColor(7);  // 恢复默认颜色
            }
        }
        if (status == D)
        {
            nexthead->x = head->x;
            nexthead->y = head->y + 1;
            if (nexthead->x == food->x && nexthead->y == food->y)  //有食物
            {
                playSound(1);  // 吃食物音效
                nexthead->next = head;
                head = nexthead;
                setColor(snakeColor);
                q = head;
                while (q != NULL)
                {
                    Pos(q->x, q->y);
                    printf("■");
                    q = q->next;
                }
                setColor(7);  // 恢复默认颜色
                score = score + add;
                createfood();
            }
            else  //没有食物
            {
                nexthead->next = head;
                head = nexthead;
                setColor(snakeColor);
                q = head;
                while (q->next->next != NULL)
                {
                    Pos(q->x, q->y);
                    printf("■");
                    q = q->next;
                }
                Pos(q->next->x, q->next->y);
                printf("  ");
                free(q->next);
                q->next = NULL;
                setColor(7);  // 恢复默认颜色
            }
        }
        if (status == L)
        {
            nexthead->x = head->x - 2;
            nexthead->y = head->y;
            if (nexthead->x == food->x && nexthead->y == food->y)  //有食物
            {
                playSound(1);  // 吃食物音效
                nexthead->next = head;
                head = nexthead;
                setColor(snakeColor);
                q = head;
                while (q != NULL)
                {
                    Pos(q->x, q->y);
                    printf("■");
                    q = q->next;
                }
                setColor(7);  // 恢复默认颜色
                score = score + add;
                createfood();
            }
            else  //没有食物
            {
                nexthead->next = head;
                head = nexthead;
                setColor(snakeColor);
                q = head;
                while (q->next->next != NULL)
                {
                    Pos(q->x, q->y);
                    printf("■");
                    q = q->next;
                }
                Pos(q->next->x, q->next->y);
                printf("  ");
                free(q->next);
                q->next = NULL;
                setColor(7);  // 恢复默认颜色
            }
        }
        if (status == R)
        {
            nexthead->x = head->x + 2;
            nexthead->y = head->y;
            if (nexthead->x == food->x && nexthead->y == food->y)  //有食物
            {
                playSound(1);  // 吃食物音效
                nexthead->next = head;
                head = nexthead;
                setColor(snakeColor);
                q = head;
                while (q != NULL)
                {
                    Pos(q->x, q->y);
                    printf("■");
                    q = q->next;
                }
                setColor(7);  // 恢复默认颜色
                score = score + add;
                createfood();
            }
            else  //没有食物
            {
                nexthead->next = head;
                head = nexthead;
                setColor(snakeColor);
                q = head;
                while (q->next->next != NULL)
                {
                    Pos(q->x, q->y);
                    printf("■");
                    q = q->next;
                }
                Pos(q->next->x, q->next->y);
                printf("  ");
                free(q->next);
                q->next = NULL;
                setColor(7);  // 恢复默认颜色
            }
        }
        if (biteself() == 1)  //判断是否会咬到自己
        {
            endgamestatus = 2;
            endgame();
        }
    }
}

void pause()  //暂停
{
    gamePaused = 1;
    while (1)
    {
        Sleep(300);
        if (GetAsyncKeyState(VK_SPACE))
        {
            gamePaused = 0;
            break;
        }
    }
}

void gamecircle()  //控制游戏
{
    if (!inColorMenu && !gamePaused) {
        setColor(6);  // 黄色
        Pos(64, 15);
        printf("不能穿墙，不能咬到自己\n");
        Pos(64, 16);
        printf("用↑.↓.←.→分别控制蛇的移动.");
        Pos(64, 17);
        printf("F1 为加速，F2 为减速\n");
        Pos(64, 18);
        printf("ESC ：退出游戏.space：暂停游戏.");
        Pos(64, 20);
        setColor(7);  // 恢复默认颜色

        // 显示当前用户
        setColor(6);  // 黄色
        Pos(64, 8);
        printf("当前用户: %s", currentUser);
        Pos(64, 9);
        printf("按F5显示游戏日志");
        setColor(7);  // 恢复默认颜色

        status = R;

        // 等待玩家输入开始游戏
        setColor(6);
        Pos(20, 13);
        printf("按任意方向键开始游戏...");
        setColor(7);
        while (!gameStarted) {
            if (GetAsyncKeyState(VK_UP) && status != D) {
                status = U;
                gameStarted = 1;
            } else if (GetAsyncKeyState(VK_DOWN) && status != U) {
                status = D;
                gameStarted = 1;
            } else if (GetAsyncKeyState(VK_LEFT) && status != R) {
                status = L;
                gameStarted = 1;
            } else if (GetAsyncKeyState(VK_RIGHT) && status != L) {
                status = R;
                gameStarted = 1;
            }
        }
        Pos(20, 13);
        printf("                              ");

        while (1)
        {
            setColor(6);  // 黄色
            Pos(64, 10);
            printf("得分：%d  ", score);
            Pos(64, 11);
            printf("每个食物得分：%d分", add);
            setColor(7);  // 恢复默认颜色

            if (GetAsyncKeyState(VK_F5))
            {
                playSound(3);  // 菜单选择音效
                gamePaused = 1;
                showGameLogs();
                system("cls");
                creatMap();
                initsnake();
                setColor(4);  // 红色
                Pos(food->x, food->y);
                printf("■");
                setColor(7);  // 恢复默认颜色
                // 重新显示游戏信息
                setColor(6);  // 黄色
                Pos(64, 8);
                printf("当前用户: %s", currentUser);
                Pos(64, 9);
                printf("按F5显示游戏日志");
                setColor(7);  // 恢复默认颜色
                gamePaused = 0;
                continue;
            }

            if (GetAsyncKeyState(VK_UP) && status != D)
            {
                status = U;
            }
            else if (GetAsyncKeyState(VK_DOWN) && status != U)
            {
                status = D;
            }
            else if (GetAsyncKeyState(VK_LEFT) && status != R)
            {
                status = L;
            }
            else if (GetAsyncKeyState(VK_RIGHT) && status != L)
            {
                status = R;
            }
            else if (GetAsyncKeyState(VK_SPACE))
            {
                pause();
            }
            else if (GetAsyncKeyState(VK_ESCAPE))
            {
                endgamestatus = 3;
                break;
            }
            else if (GetAsyncKeyState(VK_F1))
            {
                if (sleeptime >= 50)
                {
                    sleeptime = sleeptime - 30;
                    add = add + 2;
                    if (sleeptime == 320)
                    {
                        add = 2;  //防止减到1之后再加回来有错
                    }
                }
            }
            else if (GetAsyncKeyState(VK_F2))
            {
                if (sleeptime < 350)
                {
                    sleeptime = sleeptime + 30;
                    add = add - 2;
                    if (sleeptime == 350)
                    {
                        add = 1;  //保证最低分为1
                    }
                }
            }
            Sleep(sleeptime);
            snakemove();
        }
    }
}

void welcometogame()  //开始界面
{
    setColor(11);  // 青色
    Pos(40, 12);
    printf("欢迎来到贪食蛇游戏！");
    Pos(40, 25);
    system("pause");
    system("cls");
    Pos(25, 12);
    printf("用↑.↓.←.→分别控制蛇的移动， F1 为加速，F2 为减速\n");
    Pos(25, 13);
    printf("加速将能得到更高的分数。\n");
    system("pause");
    system("cls");
    setColor(7);  // 恢复默认颜色
}

void endgame()  //结束游戏
{
    playSound(2);  // 游戏结束音效
    logGameEnd();  // 记录游戏结束
    updateTopScores();  // 更新历史最高分

    system("cls");
    setColor(6);  // 黄色
    Pos(24, 12);
    if (endgamestatus == 1)
    {
        printf("对不起，您撞到墙了。游戏结束!");
    }
    else if (endgamestatus == 2)
    {
        printf("对不起，您咬到自己了。游戏结束!");
    }
    else if (endgamestatus == 3)
    {
        printf("您已经结束了游戏。");
    }
    Pos(24, 13);
    printf("您的得分是%d\n", score);
    setColor(7);  // 恢复默认颜色

    // 等待3秒让用户查看结果
    Sleep(3000);
    exit(0);
}

void gamestart()  //游戏初始化
{
    system("mode con cols=100 lines=30");
    welcometogame();
    showDifficultyMenu();
    showColorMenu();
    creatMap();
    initsnake();
    createfood();  // 确保在游戏开始时生成食物

    // 显示初始分数和用户信息
    setColor(6);  // 黄色
    Pos(64, 8);
    printf("当前用户: %s", currentUser);
    Pos(64, 9);
    printf("按F5显示游戏日志");
    Pos(64, 10);
    printf("得分：%d  ", score);
    Pos(64, 11);
    printf("每个食物得分：%d分", add);
    setColor(7);  // 恢复默认颜色
}

void registerUser()
{
    User newUser;
    FILE* userFile;

    system("cls");
    setColor(13);  // 紫色
    Pos(40, 10);
    printf("=== 用户注册 ===");
    setColor(7);  // 恢复默认颜色

    Pos(40, 12);
    printf("请输入用户名: ");
    scanf("%s", newUser.username);

    Pos(40, 14);
    printf("请输入密码: ");
    scanf("%s", newUser.password);

    userFile = fopen("users.dat", "ab");
    if (userFile == NULL) {
        Pos(40, 16);
        printf("无法打开用户文件!");
        return;
    }

    fwrite(&newUser, sizeof(User), 1, userFile);
    fclose(userFile);

    Pos(40, 16);
    printf("注册成功!");
    Sleep(1000);
}

int loginUser()
{
    User user;
    char username[MAX_USERNAME_LEN];
    char password[MAX_PASSWORD_LEN];
    FILE* userFile;
    int found = 0;

    system("cls");
    setColor(13);  // 紫色
    Pos(40, 10);
    printf("=== 用户登录 ===");
    setColor(7);  // 恢复默认颜色

    Pos(40, 12);
    printf("请输入用户名: ");
    scanf("%s", username);

    Pos(40, 14);
    printf("请输入密码: ");
    scanf("%s", password);

    userFile = fopen("users.dat", "rb");
    if (userFile == NULL) {
        Pos(40, 16);
        printf("用户文件不存在，请先注册!");
        Sleep(1000);
        return 0;
    }

    while (fread(&user, sizeof(User), 1, userFile)) {
        if (strcmp(user.username, username) == 0 &&
            strcmp(user.password, password) == 0) {
            found = 1;
            strcpy(currentUser, username);
            break;
        }
    }

    fclose(userFile);

    if (!found) {
        Pos(40, 16);
        printf("用户名或密码错误!");
        Sleep(1000);
        return 0;
    }

    return 1;
}

void showGameLogs()
{
    FILE* logFile = fopen("gamelogs.dat", "rb");
    GameLog log;
    int count = 0;
    struct tm* timeinfo;
    char timeStr[20];

    system("cls");
    setColor(13);  // 紫色
    Pos(10, 2);
    printf("=== 当前用户游戏日志 ===");
    setColor(7);  // 恢复默认颜色

    if (logFile) {
        Pos(5, 4);
        printf("用户名        开始时间            游戏时长  得分");
        Pos(5, 5);
        printf("------------------------------------------------");

        while (fread(&log, sizeof(GameLog), 1, logFile)) {
            if (strcmp(log.username, currentUser) == 0) {
                timeinfo = localtime(&log.start_time);
                strftime(timeStr, 20, "%Y-%m-%d %H:%M", timeinfo);

                Pos(5, 6 + count);
                printf("%-12s %s %5d秒 %5d分",
                       log.username, timeStr, log.duration, log.score);
                count++;

                if (count > 20) break;  // 最多显示20条记录
            }
        }
        fclose(logFile);
    }
    if (count == 0) {
        Pos(10, 6);
        printf("暂无当前用户的游戏日志");
    }

    Pos(10, 28);
    printf("按任意键返回...");
    getch();
}

void logGameStart()
{
    FILE* logFile = fopen("gamelogs.dat", "ab");
    if (logFile) {
        GameLog log;
        strcpy(log.username, currentUser);
        log.start_time = time(NULL);
        gameStartTime = log.start_time;  // 保存开始时间
        fwrite(&log, sizeof(GameLog), 1, logFile);
        fclose(logFile);
    }
}

void logGameEnd()
{
    FILE* logFile = fopen("gamelogs.dat", "rb+");
    if (logFile) {
        GameLog log;
        fseek(logFile, -sizeof(GameLog), SEEK_END);
        fread(&log, sizeof(GameLog), 1, logFile);

        log.duration = (int)difftime(time(NULL), gameStartTime);
        log.score = score;

        fseek(logFile, -sizeof(GameLog), SEEK_CUR);
        fwrite(&log, sizeof(GameLog), 1, logFile);
        fclose(logFile);
    }
}

void showDifficultyMenu()
{
    int choice = 0;
    int selected = 0;
    int key;

    gamePaused = 1;  // 暂停游戏
    while (1) {
        system("cls");
        // 标题居中显示
        Pos(30, 10);
        setColor(13);
        printf("=== 选择游戏难度 ===");
        setColor(7);

        // 统一设置选项起始输出位置
        int xPos = 20;
        for (int i = 0; i < 3; i++) {
            Pos(xPos, 12 + i);
            if (i == selected) {
                setColor(11);
                printf("-> ");
            } else {
                printf("   ");
            }
            switch (i) {
                case 0:
                    printf("简单");
                    break;
                case 1:
                    printf("中等");
                    break;
                case 2:
                    printf("困难");
                    break;
            }
            setColor(7);
        }

        key = getch();
        if (key == 72 && selected > 0) {
            playSound(3);
            selected--;
        } else if (key == 80 && selected < 2) {
            playSound(3);
            selected++;
        } else if (key == 13) {
            playSound(3);
            choice = selected;
            break;
        }
    }

    switch (choice) {
        case 0:
            sleeptime = 300;
            add = 5;
            break;
        case 1:
            sleeptime = 200;
            add = 10;
            break;
        case 2:
            sleeptime = 100;
            add = 15;
            break;
    }
    gamePaused = 0;  // 恢复游戏
}

void loadTopScores()
{
    FILE* file = fopen("topscores.dat", "rb");
    if (file) {
        fread(topScores, sizeof(TopScore), MAX_TOP_SCORES, file);
        fclose(file);
    }
}

void saveTopScores()
{
    FILE* file = fopen("topscores.dat", "wb");
    if (file) {
        fwrite(topScores, sizeof(TopScore), MAX_TOP_SCORES, file);
        fclose(file);
    }
}

void showTopScores()
{
    system("cls");
    setColor(13);  // 紫色
    Pos(10, 2);
    printf("=== 历史最高分 ===");
    setColor(7);  // 恢复默认颜色

    Pos(5, 4);
    printf("用户名        得分");
    Pos(5, 5);
    printf("-----------------");

    for (int i = 0; i < MAX_TOP_SCORES; i++) {
        if (topScores[i].score > 0) {
            Pos(5, 6 + i);
            printf("%-12s %5d分", topScores[i].username, topScores[i].score);
        }
    }

    Pos(10, 28);
    printf("按任意键返回...");
    getch();
}

void updateTopScores()
{
    for (int i = 0; i < MAX_TOP_SCORES; i++) {
        if (score > topScores[i].score) {
            for (int j = MAX_TOP_SCORES - 1; j > i; j--) {
                topScores[j] = topScores[j - 1];
            }
            strcpy(topScores[i].username, currentUser);
            topScores[i].score = score;
            saveTopScores();
            break;
        }
    }
}

void playSound(int type)
{
    switch (type) {
        case 1:  // 吃食物
            Beep(1000, 100);
            break;
        case 2:  // 游戏结束
            Beep(200, 500);
            break;
        case 3:  // 菜单选择
            Beep(500, 50);
            break;
    }
}

void showColorMenu()
{
    int choice = 0;
    int selected = 0;
    int key;
    char* colors[] = {"黑色", "蓝色", "绿色", "青色", "红色", "紫色", "白色"};
    int colorValues[] = {0, 1, 2, 3, 4, 5, 7};

    inColorMenu = 1;  // 进入颜色选择菜单，设置标志位
    gamePaused = 1;  // 暂停游戏
    system("cls");

    while (1) {
        // 标题居中显示
        Pos(30, 10);
        setColor(13);
        printf("=== 选择蛇的颜色 ===");
        setColor(7);

        // 统一设置选项起始输出位置
        int xPos = 20;
        for (int i = 0; i < 7; i++) {
            Pos(xPos, 12 + i);
            if (i == selected) {
                setColor(11);
                printf("-> ");
            } else {
                printf("   ");
            }
            printf("%s", colors[i]);
            setColor(7);
        }

        key = getch();
        if (key == 72 && selected > 0) {
            playSound(3);
            selected--;
        } else if (key == 80 && selected < 6) {
            playSound(3);
            selected++;
        } else if (key == 13) {
            playSound(3);
            choice = selected;
            break;
        }
    }

    snakeColor = colorValues[choice];
    inColorMenu = 0;  // 退出颜色选择菜单，清除标志位
    gamePaused = 0;  // 恢复游戏

    // 重新绘制游戏地图、蛇和食物等元素
    system("cls");
    creatMap();
    initsnake();
    createfood();

    // 重新显示游戏信息
    setColor(6);
    Pos(64, 8);
    printf("当前用户: %s", currentUser);
    Pos(64, 9);
    printf("按F5显示游戏日志");
    Pos(64, 10);
    printf("得分：%d  ", score);
    Pos(64, 11);
    printf("每个食物得分：%d分", add);
    setColor(7);
}

int main()
{
    int loggedIn = 0;
    int choice;

    system("mode con cols=100 lines=30");
    loadTopScores();

    // 用户系统
    while (!loggedIn) {
        system("cls");
        setColor(13);  // 紫色
        Pos(40, 10);
        printf("=== 贪吃蛇游戏 ===");
        setColor(7);  // 恢复默认颜色
        Pos(40, 12);
        printf("1. 注册");
        Pos(40, 14);
        printf("2. 登录");
        Pos(40, 16);
        printf("3. 退出");
        Pos(40, 18);
        printf("4. 查看历史最高分");
        Pos(40, 20);
        printf("请选择: ");

        choice = getch();
        switch (choice) {
            case '1':
                playSound(3);  // 菜单选择音效
                registerUser();
                break;
            case '2':
                playSound(3);  // 菜单选择音效
                loggedIn = loginUser();
                break;
            case '3':
                return 0;
            case '4':
                playSound(3);  // 菜单选择音效
                showTopScores();
                break;
        }
    }

    // 记录游戏开始
    logGameStart();

    // 开始游戏
    gamestart();
    gamecircle();
    endgame();

    return 0;
}
